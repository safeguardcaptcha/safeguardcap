<?php
header('Content-Type: application/json');

$request_uri = $_SERVER['REQUEST_URI'];
$request_method = $_SERVER['REQUEST_METHOD'];

if ($request_method === 'POST' && strpos($request_uri, '/api/verify') !== false) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!isset($data['api_key']) || !isset($data['captcha_data'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }

    // Verify API key (in a real scenario, you'd check against a database)
    if ($data['api_key'] !== 'your_api_key_here') {
        echo json_encode(['success' => false, 'message' => 'Invalid API key']);
        exit;
    }

    // Verify CAPTCHA data
    $duration = $data['captcha_data']['duration'];
    $distance = $data['captcha_data']['distance'];

    // Simple verification logic (adjust as needed)
    if ($duration > 0.5 && $duration < 5 && $distance > 100 && $distance < 1000) {
        echo json_encode(['success' => true, 'message' => 'CAPTCHA verified']);
    } else {
        echo json_encode(['success' => false, 'message' => 'CAPTCHA verification failed']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid endpoint or method']);
}