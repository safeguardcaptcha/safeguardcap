<?php
header('Content-Type: application/json');

$db_file = __DIR__ . '/api_keys.json';

function generate_api_key() {
    return bin2hex(random_bytes(16));
}

function get_client_ip() {
    return $_SERVER['REMOTE_ADDR'];
}

function can_generate_key($ip) {
    global $db_file;
    $data = json_decode(file_get_contents($db_file), true) ?: [];
    $month = date('Y-m');
    
    if (!isset($data[$ip])) {
        return true;
    }
    
    if ($data[$ip]['month'] !== $month) {
        return true;
    }
    
    return $data[$ip]['count'] < 3;
}

function save_api_key($ip, $key) {
    global $db_file;
    $data = json_decode(file_get_contents($db_file), true) ?: [];
    $month = date('Y-m');
    
    if (!isset($data[$ip]) || $data[$ip]['month'] !== $month) {
        $data[$ip] = ['month' => $month, 'count' => 1, 'keys' => [$key]];
    } else {
        $data[$ip]['count']++;
        $data[$ip]['keys'][] = $key;
    }
    
    file_put_contents($db_file, json_encode($data));
}

$client_ip = get_client_ip();

if (can_generate_key($client_ip)) {
    $new_key = generate_api_key();
    save_api_key($client_ip, $new_key);
    echo json_encode(['success' => true, 'api_key' => $new_key]);
} else {
    echo json_encode(['success' => false, 'message' => 'Monthly limit reached. Try again next month.']);
}